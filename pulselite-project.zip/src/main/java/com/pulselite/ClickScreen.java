package com.pulselite;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ClickScreen extends Screen {
    public ClickScreen() { super(Component.literal("PulseLite")); }

    private static Component label(Module m) {
        return Component.literal(m.name + ": " + (m.enabled ? "ON" : "OFF"));
    }

    @Override
    protected void init() {
        int perCol = 8;
        int top = this.height / 2 - perCol * 12;
        int i = 0;
        for (Module m : Modules.ALL) {
            int col = i / perCol, row = i % perCol;
            int x = this.width / 2 - 165 + col * 170;
            addRenderableWidget(Button.builder(label(m), b -> { m.toggle(); b.setMessage(label(m)); })
                    .bounds(x, top + row * 24, 160, 20).build());
            i++;
        }
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
