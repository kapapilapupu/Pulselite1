package com.pulselite;

import java.util.List;

public final class Modules {
    public static final Module FULLBRIGHT = new Module("Fullbright");
    public static final Module ESP_PLAYERS = new Module("ESP: Players");
    public static final Module ESP_MOBS = new Module("ESP: Mobs");
    public static final Module ESP_ITEMS = new Module("ESP: Items");
    public static final Module ZOOM = new Module("Zoom (hold C)");
    public static final Module TIMER = new Module("Timer x1.5");
    public static final Module AURA_MOBS = new Module("Aura: Hostile Mobs");
    public static final Module AURA_PLAYERS = new Module("Aura: Players");
    public static final Module SPRINT = new Module("Auto Sprint");
    public static final Module FLY = new Module("Fly");
    public static final Module NOFALL = new Module("NoFall");
    public static final Module SPEED = new Module("Speed");
    public static final Module STEP = new Module("Step");
    public static final Module REACH = new Module("Reach");
    public static final Module AUTOWALK = new Module("Auto Walk");
    public static final Module RESPAWN = new Module("Auto Respawn");
    public static final List<Module> ALL = List.of(FULLBRIGHT, ESP_PLAYERS, ESP_MOBS, ESP_ITEMS,
            ZOOM, TIMER, AURA_MOBS, AURA_PLAYERS,
            SPRINT, FLY, NOFALL, SPEED, STEP, REACH, AUTOWALK, RESPAWN);
    private Modules() {}
}
