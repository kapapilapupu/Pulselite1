package com.pulselite.mixin;

import com.pulselite.Modules;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Minecraft.class)
public class MinecraftMixin {
    @Inject(method = "shouldEntityAppearGlowing", at = @At("HEAD"), cancellable = true)
    private void pulselite$esp(Entity e, CallbackInfoReturnable<Boolean> cir) {
        boolean glow = (Modules.ESP_PLAYERS.enabled && e instanceof Player)
                || (Modules.ESP_MOBS.enabled && e instanceof LivingEntity && !(e instanceof Player))
                || (Modules.ESP_ITEMS.enabled && e instanceof ItemEntity);
        if (glow) cir.setReturnValue(true);
    }
}
