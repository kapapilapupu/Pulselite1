package com.pulselite;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import org.lwjgl.glfw.GLFW;

public class PulseLiteClient implements ClientModInitializer {
    private static KeyMapping openKey, zoomKey;
    private boolean nightApplied, zooming, timerApplied, flyApplied, stepApplied, reachApplied, walkApplied;
    private int savedFov;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("pulselite", "main"));
        openKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.pulselite.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, cat));
        zoomKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.pulselite.zoom", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, cat));
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(Minecraft mc) {
        while (openKey.consumeClick()) mc.setScreen(new ClickScreen());
        var p = mc.player;
        var lvl = mc.level;
        if (p == null || lvl == null) { nightApplied = false; timerApplied = false; flyApplied = false; stepApplied = false; reachApplied = false; walkApplied = false; return; }

        // Fullbright
        if (Modules.FULLBRIGHT.enabled) {
            if (!p.hasEffect(MobEffects.NIGHT_VISION)) {
                p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, MobEffectInstance.INFINITE_DURATION, 0, false, false, false));
            }
            nightApplied = true;
        } else if (nightApplied) {
            p.removeEffect(MobEffects.NIGHT_VISION);
            nightApplied = false;
        }

        // Zoom
        if (Modules.ZOOM.enabled && zoomKey.isDown()) {
            if (!zooming) { savedFov = mc.options.fov().get(); zooming = true; }
            mc.options.fov().set(30);
        } else if (zooming) {
            mc.options.fov().set(savedFov);
            zooming = false;
        }

        // Timer
        if (Modules.TIMER.enabled) {
            lvl.tickRateManager().setTickRate(30f);
            timerApplied = true;
        } else if (timerApplied) {
            lvl.tickRateManager().setTickRate(20f);
            timerApplied = false;
        }

        boolean moving = mc.options.keyUp.isDown() || mc.options.keyDown.isDown()
                || mc.options.keyLeft.isDown() || mc.options.keyRight.isDown();

        // Auto Sprint
        if (Modules.SPRINT.enabled && mc.options.keyUp.isDown() && !p.isShiftKeyDown() && !p.horizontalCollision
                && p.getFoodData().getFoodLevel() > 6) {
            p.setSprinting(true);
        }

        // Fly
        var ab = p.getAbilities();
        if (Modules.FLY.enabled) {
            ab.mayfly = true;
            ab.setFlyingSpeed(0.08f);
            flyApplied = true;
        } else if (flyApplied) {
            ab.setFlyingSpeed(0.05f);
            if (!p.isCreative() && !p.isSpectator()) { ab.mayfly = false; ab.flying = false; }
            flyApplied = false;
        }

        // NoFall
        if (Modules.NOFALL.enabled && p.fallDistance > 2.0) p.setOnGround(true);

        // Speed
        if (Modules.SPEED.enabled && moving && p.onGround()) {
            var v = p.getDeltaMovement();
            p.setDeltaMovement(v.x * 1.2, v.y, v.z * 1.2);
        }

        // Step
        var step = p.getAttribute(Attributes.STEP_HEIGHT);
        if (step != null) {
            if (Modules.STEP.enabled) { step.setBaseValue(1.0); stepApplied = true; }
            else if (stepApplied) { step.setBaseValue(0.6); stepApplied = false; }
        }

        // Reach
        var er = p.getAttribute(Attributes.ENTITY_INTERACTION_RANGE);
        var br = p.getAttribute(Attributes.BLOCK_INTERACTION_RANGE);
        if (er != null && br != null) {
            if (Modules.REACH.enabled) { er.setBaseValue(6.0); br.setBaseValue(6.0); reachApplied = true; }
            else if (reachApplied) { er.setBaseValue(3.0); br.setBaseValue(4.5); reachApplied = false; }
        }

        // Auto Walk
        if (Modules.AUTOWALK.enabled) { mc.options.keyUp.setDown(true); walkApplied = true; }
        else if (walkApplied) { mc.options.keyUp.setDown(false); walkApplied = false; }

        // Auto Respawn
        if (Modules.RESPAWN.enabled && p.isDeadOrDying()) p.respawn();

        // Attack aura
        if ((Modules.AURA_MOBS.enabled || Modules.AURA_PLAYERS.enabled)
                && mc.gameMode != null && p.getAttackStrengthScale(0.5f) >= 1f) {
            Entity best = null;
            double bestD = 13.0;
            for (Entity e : lvl.entitiesForRendering()) {
                if (e == p || !(e instanceof LivingEntity le) || !le.isAlive() || le.isSpectator()) continue;
                boolean ok = (Modules.AURA_PLAYERS.enabled && e instanceof Player)
                        || (Modules.AURA_MOBS.enabled && e instanceof Enemy);
                if (!ok) continue;
                double d = p.distanceToSqr(e);
                if (d <= 12.25 && d < bestD) { bestD = d; best = e; }
            }
            if (best != null) {
                mc.gameMode.attack(p, best);
                p.swing(InteractionHand.MAIN_HAND);
            }
        }
    }
}
