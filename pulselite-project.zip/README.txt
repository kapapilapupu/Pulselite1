PulseLite Fabric mod project extracted from the uploaded build.yml.

Build requirements from the configuration:
- JDK 25
- Gradle 9.5.1
- Internet access to download Minecraft/Fabric dependencies

Build command:
  gradle build

The JAR should be created in build/libs/ (expected name pulselite-1.0.0.jar).
The supplied source targets Minecraft 26.3 and Fabric; it has not been compiled or tested here.
